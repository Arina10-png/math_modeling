from my_modl_1 import a
from my_modl_2 import a
print(a)

import my_modl_1 
import my_modl_2 
print(my_modl_1.a * my_modl_2.a)