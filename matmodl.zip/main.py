import my_modl
print(my_modl.a)
b = my_modl. a**2
print(b) 
