from my_modl import *
print(a*b-c)
