import numpy as np 
a = [1,2,4]
b = np.array(a)
print(type(a))
print(type(b))
print(b*b)
print(b/b)
print(b-b)

A = np.zeros((2, 3))
print(A)
B = np.zeros((10,10))
print(B)

A[0, 2] = 5
print(A)
print(A[1, 1])

B = np.ones ((3, 2))
print(B)

A = np.ndarray(shape=(2, 3 ))
print(A)

A = np.arange(0, 10, 1)
print(A)

B = np.arange(0, 5, 0.5)
print(B)
print(A[-1])
print(len(A))

A = np.linspace(0, 10, 10)
print(A)
