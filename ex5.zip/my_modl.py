earth_mass = 5.94*10**24
gravity_constant = 6.67*10**(-11)
your_mam_mass = 100000**1000000
