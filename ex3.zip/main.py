from my_modl import a 
print(a)
