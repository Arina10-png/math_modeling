from math import sin, tan, sqrt, pi
print(sin (2*pi))
print(sin(pi))
print(sqrt(3**2 - 5*sin(pi/2)))

