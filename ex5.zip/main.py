from my_modl import gravity_constant as G
g = 500*G/10*2
print(g)
